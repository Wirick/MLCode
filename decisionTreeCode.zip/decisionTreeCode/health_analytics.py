# So this module is a bit of a solutions module for the medical claims problem. There are functions to 
# get variable rankers, random forests, health data, etc.
import rf_variable_ranker
import random_forest
import cPickle
import csv
from sklearn.externals import joblib

dr_dist_class = ['F13', 'J8G', 'JO5', 'JB8', 'JE1', 'JC9', 'JF1', 'JF9', 'JG1', 'JPA', 'JES']
data_file = 'claim.sample.csv'


def get_toy_rf():
  Data = [events for events in csv.reader(open(data_file))]
  labels = Data[0]
  forest = random_forest.RandomForest(Data[2:], 2, 4, [(6, 'd'), (8, 'd'), (9, 'd'), (10, 'd'), (11, 'c'), (13, 'd'), (14, 'd'), (16, 'd'), (17, 'd'), (18, 'c'), (19, 'c'), (21, 'd'), (22, 'd'), (23, 'd'), (24, 'd'), (25, 'd'), (26, 'd')], 12, random_forest.rf_attr_fn, dr_dist_class, len(Data[2:]))
  return forest, Data[2:] 

def get_health_data():
  Data = [events for events in csv.reader(open(data_file))]
  labels = Data[0]
  rest = Data[2:]
  return labels, rest

def get_med_ranker():
  ranker, labels = rf_variable_ranker.vr_generator( [(6, 'd'), (9, 'd'), (13, 'd'), (14, 'd'), (11, 'c'), (18, 'c')], 12, dr_dist_class, 'claim.sample.csv', 20)
  ranker.grow_trees()
  return ranker, labels

def get_med_rf():
  ranker, labels = get_med_ranker()
  forest = ranker.forest
  return forest

def toy_probe_variables():
  ranker, labels = rf_variable_ranker.vr_generator( [(6, 'd'), (9, 'd'), (13, 'd'), (14, 'd'), (11, 'c'), (18, 'c')], 12, dr_dist_class, 'claim.sample.csv', 20)
  ranker.grow_trees()
  ranker.variable_ranking()  

def probe_variables():
  ranker, labels = rf_variable_ranker.vr_generator([(6, 'd'), (8, 'd'), (9, 'd'), (10, 'd'), (11, 'c'), (13, 'd'), (14, 'd'), (16, 'd'), (17, 'd'), (18, 'c'), (19, 'c'), (21, 'd'), (22, 'd'), (23, 'd'), (24, 'd'), (25, 'd'), (26, 'd')], 12, dr_dist_class, 'claim.sample.csv', 20)
  ranker.grow_trees()
  ranker.variable_ranking()  

def probe_variables_setup():
  ranker, labels = rf_variable_ranker.vr_generator([(9, 'd'), (10, 'd'), (11, 'c'), (13, 'd'), (14, 'd'), (18, 'c'), (23, 'd'), (24, 'd'), (26, 'd')], 12, dr_dist_class, 'claim.sample.csv')
  ranker.grow_trees()

def probe_variables_from_file():
  ranker = joblib.load('med_variable_forest.pkl')
  ranker.variable_ranking()  

ranker, labels = get_med_ranker()
ranker.variable_ranking()
